# ExamStudio: Ledger Lab

Independent practice website for Assignment 2, Data Analytics in Accounting.

## Run
Serve `dist` with any static HTTP server. There is no build step or runtime dependency. For example: `python -m http.server 8000 --directory dist`.

## Content
25 source-grounded exercises across six topics, plus six Find & fix the mistake review exercises. Each exercise cites an included source and supports deterministic feedback on predefined methods. Numerical film-permit answers follow the supplied solutions workbook. SQL tempo was calculated from the provided songs database. Conceptual feedback is grounded in the supplied case instructions.

The original study inputs are supplied course materials, not authored by this project. Preserve course-material attribution. Repository visibility and the lecturer’s access must be checked before submission.

## Validation
Run `node --check dist/app.js`, `node --check dist/mistakes.js`, `node validate.cjs` and `node validate_reviews.cjs`. Validation checks answer logic, source links, content schema and regression boundaries. These checks cover deterministic feedback and content references; browser interaction checks are recorded in VALIDATION.md.

## Limitations
No arbitrary SQL/formula execution, free-text grading or measured learning claims. The mock exam is a student-designed 15-minute session, not an official exam replica. Progress stays in localStorage; live mock-exam state is session-only.

## Submission paragraphs

Find & fix the mistake asks students to review a plausible but flawed analysis, identify the error, choose a valid correction, and assess its effect on the conclusion. Numerical exercises use source payroll rows and results from the supplied songs database. For example, the payroll exercise contrasts an unweighted mean of row-level hourly rates with total wages divided by total hours. Unlike checking a final answer alone, this exposes whether students recognise the population, weighting or inference error behind the result. Feedback checks the diagnosis, repair and consequence separately, allowing a retry before the worked review is revealed. A correct payroll review unlocks a fresh source sample that requires calculation without method choices. The feature is designed to support explaining and defending analysis in an oral exam; a learning benefit has not yet been measured, and it does not claim the lecturer’s AI tutor cannot discuss these errors.

The inputs span spreadsheets, delimited text files, SQLite databases and Word instructions across several accounting contexts. Building a useful practice site requires identifying relevant skills, preserving each dataset’s grain and field definitions, and establishing defensible answers across those formats. Some instructions also need interpretation: the IntegrateCo wording about the direction of the difference conflicts with its parenthetical explanation. Turning this material into consistent questions and diagnostic feedback therefore requires content validation and accounting judgment as well as software implementation.


## GitHub Pages
The included `.github/workflows/pages.yml` validates the project and publishes `dist/` to GitHub Pages. In the GitHub repository, choose **Settings → Pages → Source → GitHub Actions**. Push to `main` or run the workflow manually. No API keys or build dependencies are needed. The workflow deployment output is the authoritative website address.

## Assignment deliverables
See `SUBMISSION.md` for the two required paragraphs and current link status. The site includes the same paragraphs under About the project. See `VALIDATION.md` for reproducible checks and limitations.
